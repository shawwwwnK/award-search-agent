"""Controls for the four assumption failures in the stopped campaign verifier."""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import ledger
import preview
import preview_loader
import run
import verify

from award_agent.results.contracts import ResultsConfig


def test_observed_fault_code_is_exact() -> None:
    findings = [{"code": "visible_internal_alias", "outcome": "failed"}]
    assert verify.observed_fault_issues(
        expected_code="visible_internal_alias", first_findings=findings,
        correction_count=1) == []
    assert verify.observed_fault_issues(
        expected_code="empty_explanation", first_findings=findings,
        correction_count=1)
    assert verify.observed_fault_issues(
        expected_code="visible_internal_alias", first_findings=findings,
        correction_count=0)


def test_one_pass_api_incomplete_is_valid_failure() -> None:
    failed = SimpleNamespace(delivery_outcome="not_delivered", resolved=None,
                             passes=[SimpleNamespace(phase="selection", outcome="api_error")])
    assert verify.failure_shape_issues(failed) == []
    failed.resolved = object()
    assert verify.failure_shape_issues(failed)


def test_guidance_required_only_in_applicable_branch() -> None:
    marker = "same-program preference"
    complete = {"instructions": "explain supported Ranking perspectives"}
    incomplete = {"instructions": "explain the same-program preference"}
    assert verify.branch_guidance_issues(complete, incomplete=False, marker=marker) == []
    assert verify.branch_guidance_issues(incomplete, incomplete=True, marker=marker) == []
    assert verify.branch_guidance_issues(complete, incomplete=True, marker=marker)


def test_empty_comparison_pairs_valid_for_single_lead() -> None:
    assert verify.comparison_pairs_issues([], same_role_selected=1) == []
    assert verify.comparison_pairs_issues([], same_role_selected=2)
    assert verify.comparison_pairs_issues(None, same_role_selected=1)


def test_six_source_identities_include_three_distinct_ranking_exports() -> None:
    cases = run.source_registry()
    assert len(cases) == 6
    assert sum(row["kind"] == "ranking_projection" for row in cases.values()) == 3
    keys = {(run.projection_for(case).receipt.source_digest,
             run.projection_for(case).receipt.view_digest) for case in cases}
    assert len(keys) == 6


def test_preview_shows_real_flight_card_and_inline_cash() -> None:
    path = Path("evidence/results-stage/m2/structured/2026-10-28-fast-default/review-bundles/q119/evidence.json")
    evidence = json.loads(path.read_text())
    journey = evidence["journeys"][0]
    artifact = {"evidence": evidence, "resolved": {"blocks": [
        {"kind": "narrative", "text": "A shorter trip may fit you."},
        {"kind": "journey_card", "label": "Aeroplan via Hong Kong",
         "canonical_id": journey["candidate_id"], "journey": journey,
         "award_component": next(c for c in evidence["components"]
                                 if c["observation_id"] == journey["award_observation_id"]),
         "text": "The shorter journey, with an overnight departure."},
        {"kind": "cash_sentence", "text": "A separate cash fare was quoted at USD 440."},
    ]}}
    markdown = preview.render_markdown(artifact)
    page = preview.render_html(artifact)
    assert "Flight card" in markdown and "SFO–BKK" in markdown
    assert "Jan 15" in markdown and "65,000 Aeroplan points" in markdown
    assert "Flights: SFO–HKG" in markdown
    assert "Source updated" in markdown and "Price basis unconfirmed" in markdown
    assert "USD 440" in markdown and markdown.count("Flight card") == 1
    assert "The shorter journey" in markdown
    assert "<article aria-label='Flight card'>" in page
    assert "Aeroplan via Hong Kong" in page


def test_campaign_cap_is_separate_from_stopped_campaign() -> None:
    settings = ledger.campaign()
    assert settings["maximum_iterations"] == 20
    assert settings["maximum_generation_calls"] == 600
    assert ledger.CAMPAIGN.parent.name == "2026-10-29-category-led"


def test_preview_does_not_present_opaque_component_as_flight() -> None:
    reported = {"origin": "SFO", "destination": "HKG", "reported": True,
                "departure": {"local_iso": "2027-01-01T08:00:00-08:00"},
                "arrival": {"local_iso": "2027-01-02T10:00:00+08:00"},
                "flight_number": {"state": "value", "value": "UA1"},
                "cabin": {"state": "absent", "value": None}}
    opaque = dict(reported, reported=False)
    assert len(preview._legs([reported])) == 1
    assert preview._legs([opaque]) == []


def test_lead_card_keeps_cash_fare_role_and_known_scope() -> None:
    lead = {"kind": "lead_card", "label": "Positioning flight to check",
            "lead": {"missing_information": ["no_complete_matched_journey"]},
            "lead_component": {"origin": "SFO", "destination": "LAX",
                "departure_date": "2027-01-01", "cabin": {"state": "absent"},
                "points": {"state": "absent"}, "program": {"state": "absent"},
                "seats": {"state": "absent"},
                "money": {"kind": "cash_fare", "unit": "major", "scope": "per_traveler",
                    "raw_amount": {"state": "value", "value": 59},
                    "raw_currency": {"state": "value", "value": "USD"}},
                "legs": [{"origin": "SFO", "destination": "LAX", "reported": False}]}}
    rows = preview._card(lead, {}, 1)
    assert "Cash fare USD 59.00 quote per traveler" in rows
    assert not any(row.startswith("Taxes ") for row in rows)
    assert not any(row.startswith("Reported flights:") for row in rows)


def test_cash_component_endpoint_schedule_without_invented_leg() -> None:
    component = {"kind": "cash_itinerary", "origin": "SFO", "destination": "LAX",
                 "legs": [{"reported": False, "origin": "SFO", "destination": "LAX",
                           "departure": {"local_iso": "2027-01-08T08:55:00-08:00"},
                           "arrival": {"local_iso": "2027-01-08T10:31:00-08:00"},
                           "flight_number": {"state": "absent"}}]}
    sentence = preview._cash_component_schedule(component)
    assert sentence is not None
    assert "departs 8:55 AM, Jan 8, 2027 (SFO local)" in sentence
    assert "arrives 10:31 AM, Jan 8, 2027 (LAX local)" in sentence
    assert "Individual flight details unreported" in sentence
    assert "Flight" not in sentence.split(":", 1)[0]
    date_only = dict(component, departure_date="2027-01-08", legs=[{
        "reported": False, "origin": "SFO", "destination": "LAX",
        "departure": {"local_iso": None}, "arrival": {"local_iso": None}}])
    assert preview._cash_component_schedule(date_only) == (
        "Separately booked SFO–LAX component: 2027-01-08; exact flight times unavailable.")


def test_old_run_uses_its_archived_preview_source() -> None:
    path = run.RUNS / "c01-scout-prior-conditional"
    if not path.exists():
        return
    from award_agent.results.category import parse_category_artifact

    artifact = parse_category_artifact((path / "artifact.json").read_bytes())
    archived_markdown, archived_html = preview_loader.render_saved(path, artifact)
    assert archived_markdown == (path / "answer-preview.md").read_text()
    assert archived_html == (path / "answer-preview.html").read_text()
    assert "Separately booked SFO–LAX component:" not in archived_markdown
    assert "Separately booked SFO–LAX component:" in preview.render_markdown(artifact)


def test_archived_source_config_and_profile_bind_to_artifact(tmp_path: Path) -> None:
    case = "ranking-business"
    source_bytes = run.source_path(case).read_bytes()
    config_bytes = run.CONFIG.read_bytes()
    source = run.projection_for(case)
    config = ResultsConfig.model_validate_json(config_bytes)
    artifact = SimpleNamespace(evidence=SimpleNamespace(source=source), config=config,
        profile="category-c01", resolved=None, generation_outcome="api_error",
        validation_outcome="unavailable", delivery_outcome="not_delivered",
        selected_pass_index=None, selection_findings=())
    recorded = {"case": case, "candidate": "category-c01",
                "source_sha256": ledger.sha256(run.source_path(case))}
    summary = {"source_sha256": recorded["source_sha256"], "case": case,
               "candidate": "category-c01", "generation_outcome": "api_error",
               "validation_outcome": "unavailable", "delivery_outcome": "not_delivered",
               "selected_pass_index": None, "selection_failed_findings": []}
    check = lambda: verify._artifact_bindings_issues(
        artifact, summary, recorded, source_bytes, config_bytes, tmp_path)
    assert check() == []
    artifact.profile = "category-c02"
    assert "artifact profile differs from run settings" in check()
    artifact.profile = "category-c01"
    summary["delivery_outcome"] = "delivered"
    assert "summary delivery_outcome differs from artifact" in check()
    summary["delivery_outcome"] = "not_delivered"
    altered = source.model_copy(update={"receipt": source.receipt.model_copy(
        update={"source_digest": "0" * 64})})
    artifact.evidence.source = altered
    assert "artifact source differs from archived source" in check()


def test_pass_requests_bind_to_saved_api_files(tmp_path: Path) -> None:
    request = {"model": "gpt-6-luna", "input": "frozen source"}
    ledger.write_new(tmp_path / "pass-01" / "count-request.json", request)
    ledger.write_new(tmp_path / "pass-01" / "count-receipt.json", {"input_tokens": 10})
    ledger.write_new(tmp_path / "pass-01" / "generation-request.json", {
        **request, "max_output_tokens": 8192, "store": False,
        "truncation": "disabled", "stream": True, "service_tier": "fast"})
    ledger.write_new(tmp_path / "pass-01" / "writer-receipt.json", {"status": "completed"})
    receipt = SimpleNamespace(model_dump=lambda **_: {"input_tokens": 10})
    writer_receipt = SimpleNamespace(model_dump=lambda **_: {"status": "completed"})
    item = SimpleNamespace(request=request, writer_called=True, phase="selection",
                           input_token_receipt=receipt, writer_receipt=writer_receipt)
    settings = SimpleNamespace(service_tier="fast")
    artifact = SimpleNamespace(passes=(item,), config=SimpleNamespace(max_output_tokens=8192),
        selector_settings=settings, composer_settings=settings, correction_settings=settings)
    assert verify._pass_bindings_issues(artifact, tmp_path,
                                       {"count": 1, "generation": 1}) == []
    item.request = {"model": "gpt-6-luna", "input": "forged source"}
    assert any("request differs" in issue for issue in
               verify._pass_bindings_issues(artifact, tmp_path,
                                            {"count": 1, "generation": 1}))
