"""Prepare source-grounded, profile-blind answer bundles from saved live runs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import ledger
import run

HERE = Path(__file__).resolve().parent
INDEX = HERE / "review-index.json"


def create(run_name: str, bundle_name: str) -> Path:
    if (not run_name or Path(run_name).name != run_name or
            not bundle_name or Path(bundle_name).name != bundle_name):
        raise ValueError("run and bundle names must be single path components")
    source = run.RUNS / run_name
    artifact_path = source / "artifact.json"
    if not artifact_path.is_file():
        raise FileNotFoundError("run artifact is missing")
    if ledger.read_json(source / "settings.json").get("recovery_diagnostic"):
        raise ValueError("controlled recovery cannot enter blind natural-answer review")
    from preview_loader import render_saved

    from award_agent.results.category import parse_category_artifact, replay_category_results

    artifact = parse_category_artifact(artifact_path.read_bytes())
    replayed = replay_category_results(artifact)
    if replayed != artifact.resolved or replayed is None:
        raise ValueError("saved answer does not replay or is unavailable")
    if artifact.selected_pass_index is None:
        raise ValueError("delivered answer lacks selected pass")
    document = artifact.passes[artifact.selected_pass_index].document
    if document is None:
        raise ValueError("selected pass lacks document")
    markdown, html = render_saved(source, artifact)
    if ((source / "answer-preview.md").read_text() != markdown or
            (source / "answer-preview.html").read_text() != html):
        raise ValueError("saved review preview differs from replay")
    index = ledger.read_json(INDEX) if INDEX.exists() else {}
    if bundle_name in index or any(row["run"] == run_name for row in index.values()):
        raise ValueError("review bundle already indexed")
    target = HERE / "review-bundles" / bundle_name
    target.mkdir(parents=True, exist_ok=False)
    ledger.write_new(target / "document.json", document.model_dump(mode="json"))
    resolved_for_review = replayed.model_dump(mode="json")
    resolved_for_review.pop("findings", None)
    ledger.write_new(target / "resolved.json", resolved_for_review)
    ledger.write_new(target / "evidence.json", artifact.evidence.model_dump(mode="json"))
    ledger.write_new(target / "references.json",
                     artifact.selector_prepared.structured.references.model_dump(mode="json"))
    selector = artifact.passes[0]
    selection_wire = json.loads(selector.raw_wire) if selector.raw_wire else {}
    landscape = ((artifact.focus_prepared.packet.get("category_landscape") or {})
                 if artifact.focus_prepared is not None else {})
    ledger.write_new(target / "selection-audit.json", {
        "selected": selector.selection.model_dump(mode="json") if selector.selection else None,
        "omitted_reasons": selection_wire.get("omitted", []),
        "category_landscape": landscape,
        "availability_guidance": replayed.availability_guidance,
    })
    (target / "answer.md").write_text(markdown, encoding="utf-8")
    (target / "answer.html").write_text(html, encoding="utf-8")
    index[bundle_name] = {"run": run_name,
                          "artifact_sha256": ledger.sha256(artifact_path),
                          "answer_sha256": ledger.sha256(target / "answer.md")}
    temporary = INDEX.with_suffix(".tmp")
    temporary.write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    temporary.replace(INDEX)
    return target


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True)
    parser.add_argument("--bundle", required=True)
    args = parser.parse_args()
    print(create(args.run, args.bundle))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
