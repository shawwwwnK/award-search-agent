# Blind category-led Results M2 review

Review the assigned answer, card display, selection audit, selected document and canonical source
without reading the run's candidate, prompts, latency, token counts or other
reviews. Record source field citations for material errors. Preserve uncertainty.

Judge H (source truth, including comparisons and quote scope), U (a defensible
choice or useful no-complete next checks), M2 (natural connected answer, individual
reasons and downsides, consolidated limits), C (meaningful supported tradeoffs),
K (Ranking category perspectives and overlaps survive selection), and P (flight
facts appear in source-resolved cards, prose explains their meaning; full-cash
context is one brief source-faithful sentence). K requires materially different
available perspectives, not a fixed one-per-category quota or invented cost
member. Possible or undetermined costs must be natural-language uncertainty.
No complete journey means research leads with no style membership.

Original 3 Results sources are historical repeated cases. The other 3 Ranking
exports are distinct saved projections, not provider-fresh holdouts. Source
coverage and population reliability must be stated separately from this review.

Write `review.json` with the six axes and `findings`, each citing exact source
identity/field for any factual or category error. Do not infer a clean pass from
mechanical checks. An independent complete explorer remains a separate contract
check, not a reason to excuse a misleading opening answer.
