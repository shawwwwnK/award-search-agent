"""Isolated category-led Results experiment with exact offline replay."""

from __future__ import annotations

import json
import re
import time
from collections.abc import Callable
from typing import Any, cast

from award_agent.providers.contracts import content_digest
from award_agent.ranking.projection_contracts import SolutionProjection

from .category_contracts import CategoryAnswer, CategoryArtifact, CategoryBlock
from .contracts import CheckFinding, ResultsConfig, ResultsInputMeasurer
from .currency import FxAcquisition
from .focused import (
    _pass,
    _prepared,
    _replay_pass,
    prepare_focused_composer,
    prepare_focused_selector,
)
from .focused_packet import decode_selection_v2, selection_schema_v2
from .focused_records import writer_packet
from .focused_selector_records import selector_packet
from .focused_traveler_evidence import build_traveler_evidence
from .focused_v4 import _findings
from .focused_wire import decode as decode_document
from .focused_wire import schema as document_schema
from .interactive_contracts import InteractivePreparedInput, InteractiveSettings, InteractiveWriter
from .presentation import resolve_workspace
from .runner import RequestEnvelope, choose_recoverable
from .structured import resolve_structured_document
from .structured_contracts import StructuredDocument, StructuredSelection
from .workspace_contracts import WorkspaceEvidence

MAX_NONBENCHMARK = 6
MAX_TOTAL = 7
_SETTINGS = InteractiveSettings(reasoning_effort="low", service_tier="fast")
_PROFILE_INSTRUCTIONS: dict[str, tuple[str, str]] = {
    "category-c01": (
        "Select a compact set of exact source references for a traveler answer. "  # noqa: ISC004
        "Ranking's time, cost, and premium memberships are authoritative and overlap. "
        "Represent every materially different available category perspective; one "
        "journey may represent several. Do not fill a quota or select near-identical "
        "journeys without a supported traveler benefit. Preserve conditional journeys "
        "and uncertain cost states. If no complete journey exists, choose useful "
        "different research leads without assigning styles. Include one direct cash "
        "benchmark if available. The full explorer remains separate. Return JSON "
        "choices with k=j|b|l and exact r alias, plus omitted category reasons. "
        "A reason is audit-only; do not invent a source fact or traveler preference.",
        "Write one natural traveler answer around Ranking's time, cost, and premium "  # noqa: ISC004
        "perspectives from the selected exact authoring_records. Make the category "
        "labels visible in prose, but choose an organic order. Explain each useful "
        "journey's supported reason to consider it, meaningful downside and local "
        "tradeoff. Show overlapping category strengths once, with one journey card. "
        "A reference block is a SOURCE-RESOLVED CARD: write the short reason in v "
        "and a natural label in n; do not copy flight schedules, routes, seats, "
        "points or taxes into prose just to fill a card. Code renders card facts. "
        "Use k=p or a for journey cards, k=l for research lead cards, and k=t "
        "for connecting prose. The k=b block is a SOURCE-BOUND INLINE CASH "
        "SENTENCE, not a cash itinerary card: its v must contain exactly one brief "
        "sentence with the source's true origin-to-destination quote and material "
        "uncertainty; choose the exact benchmark r. Do not imply the quote covers "
        "other connecting cities. For no complete journey, compare supported "
        "research directions, not invented styles or itineraries. Explain shared "
        "missing evidence once, with choice-specific risks near the affected "
        "choice. Do not claim cheapest overall from incomplete or unknown-scope "
        "amounts, or compare points from different programs as economic value. "
        "Use only exact references in authoring_records. Every concrete option "
        "discussed needs its own visible exact card or cash sentence. Never print "
        "internal J/A/C aliases. Output JSON blocks in reading order."
    ),
}


def _envelope(config: ResultsConfig, settings: InteractiveSettings, instructions: str,
              packet: dict[str, object], schema: dict[str, object], *, name: str,
              previous_wire: str | None = None,
              feedback: tuple[CheckFinding, ...] = ()) -> RequestEnvelope:
    payload: dict[str, object] = {"packet": packet}
    if previous_wire is not None:
        payload["previous_wire"] = json.loads(previous_wire)
        payload["feedback"] = [item.model_dump(mode="json") for item in feedback]
    input_text = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    schema_text = json.dumps(schema, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    request: dict[str, object] = {
        "model": config.model, "reasoning": {"effort": settings.reasoning_effort},
        "instructions": instructions, "input": input_text,
        "text": {"format": {"type": "json_schema", "name": name,
                            "strict": True, "schema": schema}},
    }
    size = len((instructions + input_text).encode()) + len(schema_text.encode())
    return RequestEnvelope(request, size, size + config.prompt_overhead_tokens +
                           config.max_output_tokens, content_digest(instructions + input_text),
                           content_digest(schema_text))


def _selection_schema(selector: InteractivePreparedInput,
                      projection: SolutionProjection) -> dict[str, object]:
    schema = selection_schema_v2(selector.structured, projection, max_references=MAX_TOTAL)
    properties = cast(dict[str, Any], schema["properties"])
    properties["omitted"] = {"type": "array", "items": {"type": "object",
        "additionalProperties": False,
        "properties": {"style": {"type": "string", "enum": ["time", "cost", "premium"]},
                       "reason": {"type": "string"}},
        "required": ["style", "reason"]}}
    schema["required"] = ["choices", "omitted"]
    return schema


def _decode_selection(raw: str, selector: InteractivePreparedInput,
                      projection: SolutionProjection) -> StructuredSelection:
    value = json.loads(raw)
    if not isinstance(value, dict) or set(value) != {"choices", "omitted"} or \
            not isinstance(value["omitted"], list):
        raise ValueError("category selection requires choices and omitted reasons")
    if (any(not isinstance(row, dict) or set(row) != {"style", "reason"} or
            row["style"] not in {"time", "cost", "premium"} or
            not isinstance(row["reason"], str) for row in value["omitted"]) or
            len({row["style"] for row in value["omitted"]}) != len(value["omitted"])):
        raise ValueError("category omission notes are invalid")
    selection = decode_selection_v2({"choices": value["choices"]},
                                    selector.structured, projection,
                                    max_references=MAX_TOTAL)
    if len(selection.journey_ids) + len(selection.incomplete_observation_ids) > MAX_NONBENCHMARK:
        raise ValueError("category selection exceeds six nonbenchmark references")
    return selection


def _selection_findings(raw: str, selection: StructuredSelection,
                        projection: SolutionProjection) -> tuple[CheckFinding, ...]:
    omitted = {row["style"]: row["reason"].strip()
               for row in json.loads(raw)["omitted"]}
    indexes = projection.view.indexes
    rows: list[CheckFinding] = []
    if projection.view.direct_cash_observation_ids and selection.benchmark_observation_id is None:
        rows.append(CheckFinding(code="cash_context_omitted", outcome="failed",
            scope="benchmark", message="Available full-cash context was omitted."))
    for style in ("time", "cost", "premium"):
        available = set(getattr(indexes, style))
        selected = available.intersection(selection.journey_ids)
        if available and not selected:
            rows.append(CheckFinding(code="category_omitted", outcome="unchecked" if
                omitted.get(style) else "failed",
                scope="shared", message=f"Available {style} perspective omitted: "
                f"{omitted.get(style) or 'no audit reason supplied'}"))
        elif style in omitted:
            rows.append(CheckFinding(code="spurious_category_omission", outcome="failed",
                scope="shared", message=f"{style} omission note contradicts selection"))
    return tuple(rows)


def _focus(selection: StructuredSelection, selector: InteractivePreparedInput,
           projection: SolutionProjection, evidence: WorkspaceEvidence,
           ) -> InteractivePreparedInput:
    focus = prepare_focused_composer(selection, selector, projection, evidence,
                                     composition_format="complete-v18")
    packet = dict(focus.packet)
    packet["traveler_evidence"] = build_traveler_evidence(focus, evidence)
    packet["source_scope"] = {
        "full_selectable_journey_count": len(cast(list[object], selector.packet["journey_rows"])),
        "full_selectable_lead_count": len(cast(list[object], selector.packet["lead_rows"])),
        "full_direct_cash_benchmark_count": len(cast(list[object], selector.packet["benchmark_refs"])),
        "selected_journey_count": len(selection.journey_ids),
        "selected_lead_count": len(selection.incomplete_observation_ids),
        "selected_benchmark_count": int(selection.benchmark_observation_id is not None),
    }
    packet["editorial_plan"] = []
    packet["temporal_comparisons"] = []
    indexes = projection.view.indexes
    selected = set(selection.journey_ids)
    aliases = cast(dict[str, str], focus.packet["wire_aliases"])
    by_short = {short: long for long, short in aliases.items()}
    reverse = {canonical: by_short[alias]
               for alias, canonical in selector.structured.references.journeys.items()
               if canonical in selected}
    packet["category_landscape"] = {
        "available_counts": {style: len(getattr(indexes, style))
                             for style in ("time", "cost", "premium")},
        "selected_members": {style: [reverse[item] for item in getattr(indexes, style)
                                     if item in selected]
                             for style in ("time", "cost", "premium")},
        "possible_cost_count": len(indexes.possible_cost),
        "meaning": "Ranking memberships are source facts; counts are journey variants, not discoveries.",
    }
    return _prepared(packet, focus.structured)


def _writer_input(focus: InteractivePreparedInput) -> dict[str, object]:
    result = writer_packet(focus)
    result["category_landscape"] = focus.packet["category_landscape"]
    return result


def _document_findings(document: StructuredDocument, projection: SolutionProjection,
                       focus: InteractivePreparedInput) -> tuple[CheckFinding, ...]:
    rows = list(_findings(document, projection, focus))
    shown = {block.reference_id for block in document.blocks
             if block.kind == "reference" and block.reference_kind == "journey"}
    shown_list = [block.reference_id for block in document.blocks
                  if block.kind == "reference" and block.reference_kind == "journey"]
    if len(shown_list) != len(shown):
        rows.append(CheckFinding(code="duplicate_journey_card", outcome="failed",
            scope="shared", message="Explain each exact journey with one card."))
    cash_blocks = [block for block in document.blocks
                   if block.kind == "reference" and block.reference_kind == "benchmark"]
    if len(cash_blocks) > 1:
        rows.append(CheckFinding(code="repeated_cash_sentence", outcome="failed",
            scope="benchmark", message="Show the full-cash comparison once."))
    lead_list = [block.reference_id for block in document.blocks
                 if block.kind == "reference" and block.reference_kind == "lead"]
    if len(lead_list) != len(set(lead_list)):
        rows.append(CheckFinding(code="duplicate_lead_card", outcome="failed",
            scope="incomplete", message="Show each research lead once."))
    landscape = cast(dict[str, object], focus.packet["category_landscape"])
    selected_members = cast(dict[str, list[str]], landscape["selected_members"])
    aliases = cast(dict[str, str], focus.packet["wire_aliases"])
    refs = focus.structured.references.journeys
    for style in ("time", "cost", "premium"):
        selected = {refs[aliases[alias]] for alias in selected_members[style]}
        if selected and not shown.intersection(selected):
            rows.append(CheckFinding(code="selected_category_not_shown", outcome="failed",
                scope="shared", message=f"Selected {style} journey has no visible card"))
    for index, block in enumerate(document.blocks):
        if block.kind == "reference" and block.reference_kind == "benchmark":
            sentence = block.text.strip()
            if not sentence or len(re.findall(r"[.!?](?:\s|$)", sentence)) != 1:
                rows.append(CheckFinding(code="cash_not_one_sentence", outcome="failed",
                    scope="benchmark", reference_id=block.reference_id, part_index=index,
                    message="Cash context must be one brief sentence."))
    return tuple(rows)


def _answer(document: StructuredDocument, focus: InteractivePreparedInput,
            evidence: WorkspaceEvidence, findings: tuple[CheckFinding, ...],
            selection_findings: tuple[CheckFinding, ...]) -> CategoryAnswer:
    resolved = resolve_structured_document(document, focus.structured, evidence, findings)
    components = {item.observation_id: item for item in evidence.components}
    by_assessment = {row.assessment_id: row for row in evidence.source.view.assessments}
    assessments = {option.candidate_id: tuple(by_assessment[assessment_id].model_dump(mode="json")
                   for assessment_id in option.assessment_ids)
                   for option in evidence.source.view.alternatives}
    blocks: list[CategoryBlock] = []
    for block in resolved.blocks:
        if block.kind == "narrative":
            blocks.append(CategoryBlock(kind="text", text=block.text))
        elif block.reference_kind == "journey" and block.journey is not None:
            journey = block.journey
            blocks.append(CategoryBlock(kind="journey_card", text=block.text,
                label=block.label, canonical_id=block.canonical_id, journey=journey,
                award_component=components.get(journey.award_observation_id),
                cash_component=components.get(journey.cash_observation_id or ""),
                ranking_assessments=assessments.get(journey.candidate_id, ())))
        elif block.reference_kind == "lead" and block.lead is not None:
            blocks.append(CategoryBlock(kind="lead_card", text=block.text,
                label=block.label, canonical_id=block.canonical_id, lead=block.lead,
                lead_component=components.get(block.lead.award_observation_id or "") or
                               components.get(block.lead.cash_observation_id or "")))
        elif block.reference_kind == "benchmark" and block.component is not None:
            blocks.append(CategoryBlock(kind="cash_sentence", text=block.text,
                canonical_id=block.canonical_id, benchmark_component=block.component))
        else:
            raise ValueError("category answer contains an unavailable selected reference")
    return CategoryAnswer(selected_journey_ids=resolved.selected_journey_ids,
        blocks=tuple(blocks), availability_guidance=resolved.availability_guidance,
        findings=selection_findings + findings)


def _requests(projection: SolutionProjection, config: ResultsConfig,
              selector: InteractivePreparedInput, focus: InteractivePreparedInput | None,
              profile: str, *, previous_wire: str | None = None,
              feedback: tuple[CheckFinding, ...] = (),
              ) -> RequestEnvelope:
    selection_guide, author_guide = _PROFILE_INSTRUCTIONS[profile]
    if focus is None:
        return _envelope(config, _SETTINGS, selection_guide,
            selector_packet(selector), _selection_schema(selector, projection),
            name="CategorySelection")
    guide = author_guide
    if previous_wire is not None:
        guide += " Repair the same full answer from frozen facts and findings."
    if config.authoring_guidance and config.authoring_guidance.strip():
        guide += "\n" + config.authoring_guidance
    return _envelope(config, _SETTINGS, guide, _writer_input(focus),
        document_schema(focus), name="CategoryDocument",
        previous_wire=previous_wire, feedback=feedback)


def run_category_results(projection: SolutionProjection, config: ResultsConfig,
                         writer: InteractiveWriter,
                         input_measurer: ResultsInputMeasurer | None = None, *,
                         fx_acquisition: FxAcquisition | None = None,
                         profile: str = "category-c01") -> CategoryArtifact:
    """Run one immutable category hypothesis; no implicit public-default switch."""
    if profile not in _PROFILE_INSTRUCTIONS or config.model != "gpt-6-luna":
        raise ValueError("unknown category profile or non-Luna model")
    started = time.perf_counter()
    evidence = resolve_workspace(projection, fx_acquisition=fx_acquisition)
    selector = prepare_focused_selector(projection, config, evidence,
                                        selection_format="roles-v20")
    decode: Callable[[str], StructuredSelection] = lambda raw: _decode_selection(raw, selector, projection)
    first = _pass("selection", _requests(projection, config, selector, None, profile),
        config, _SETTINGS, writer, input_measurer, decode,
        projection=projection, prepared=selector)
    passes = [first]
    focus = None
    selection_findings: tuple[CheckFinding, ...] = ()
    if first.outcome == "recoverable":
        assert first.selection is not None and first.raw_wire is not None
        selection_findings = _selection_findings(first.raw_wire, first.selection, projection)
        focus = _focus(first.selection, selector, projection, evidence)
        decode_author: Callable[[str], StructuredDocument] = lambda raw: decode_document(raw, focus, projection)
        second = _pass("composition", _requests(projection, config, selector, focus, profile),
            config, _SETTINGS, writer, input_measurer, decode_author,
            projection=projection, prepared=focus, checker=_document_findings)
        passes.append(second)
        failures = tuple(f for f in second.findings if f.outcome == "failed")
        if second.outcome == "recoverable" and failures:
            assert second.raw_wire is not None
            passes.append(_pass("correction", _requests(projection, config, selector,
                focus, profile, previous_wire=second.raw_wire, feedback=failures),
                config, _SETTINGS, writer, input_measurer, decode_author,
                projection=projection, prepared=focus, checker=_document_findings))
    recoverable = tuple((index - 1, item.findings) for index, item in enumerate(passes)
                        if index >= 1 and item.outcome == "recoverable" and item.document is not None)
    chosen = (choose_recoverable(recoverable)[0] + 1 if recoverable else None)
    chosen_index = chosen if chosen is not None else 0
    resolved = (_answer(cast(StructuredDocument, passes[chosen_index].document),
                        cast(InteractivePreparedInput, focus), evidence,
                        passes[chosen_index].findings, selection_findings)
                if chosen is not None else None)
    terminal = passes[-1]
    validation = ("unavailable" if resolved is None else
                  "annotated" if any(f.outcome == "failed" for f in selection_findings) or any(f.outcome == "failed" for f in
                  passes[chosen_index].findings) else "clean")
    artifact = CategoryArtifact(profile=profile, evidence=evidence, config=config,
        selector_settings=_SETTINGS, composer_settings=_SETTINGS,
        correction_settings=_SETTINGS, selector_prepared=selector,
        focus_prepared=focus, passes=tuple(passes), selection_findings=selection_findings,
        selected_pass_index=chosen, generation_outcome=cast(Any,
            "success" if resolved is not None else terminal.outcome),
        validation_outcome=cast(Any, validation),
        delivery_outcome="delivered" if resolved is not None else "not_delivered",
        resolved=resolved,
        resolved_digest=content_digest(resolved.model_dump(mode="json")) if resolved else None,
        runtime_seconds=time.perf_counter() - started)
    return artifact


def replay_category_results(artifact: CategoryArtifact) -> CategoryAnswer | None:
    """Rebuild every preparation, request, check and displayed card from saved source."""
    if artifact.profile not in _PROFILE_INSTRUCTIONS or any(settings != _SETTINGS for settings in
            (artifact.selector_settings, artifact.composer_settings,
             artifact.correction_settings)):
        raise ValueError("saved category profile/settings differ")
    projection = SolutionProjection.model_validate(artifact.evidence.source.model_dump(mode="json"))
    evidence = resolve_workspace(projection, fx_acquisition=artifact.evidence.fx_acquisition)
    if evidence != artifact.evidence:
        raise ValueError("saved category source differs")
    selector = prepare_focused_selector(projection, artifact.config, evidence,
                                        selection_format="roles-v20")
    if artifact.selector_prepared != selector or not 1 <= len(artifact.passes) <= 3:
        raise ValueError("saved category selector or pass count differs")
    first = artifact.passes[0]
    if first.phase != "selection":
        raise ValueError("saved category first phase differs")
    _replay_pass(first, _requests(projection, artifact.config, selector, None, artifact.profile),
        artifact.config, lambda raw: _decode_selection(raw, selector, projection),
        projection, selector)
    focus = None
    selection_findings: tuple[CheckFinding, ...] = ()
    if first.outcome == "recoverable":
        assert first.selection is not None and first.raw_wire is not None
        selection_findings = _selection_findings(first.raw_wire, first.selection, projection)
        focus = _focus(first.selection, selector, projection, evidence)
        if len(artifact.passes) < 2 or artifact.passes[1].phase != "composition":
            raise ValueError("saved category composition is missing")
        _replay_pass(artifact.passes[1], _requests(projection, artifact.config, selector,
            focus, artifact.profile), artifact.config,
            lambda raw: decode_document(raw, focus, projection), projection, focus,
            checker=_document_findings)
        failures = tuple(f for f in artifact.passes[1].findings if f.outcome == "failed")
        if len(artifact.passes) == 3:
            if not failures or artifact.passes[1].outcome != "recoverable" or \
                    artifact.passes[2].phase != "correction" or \
                    artifact.passes[1].raw_wire is None:
                raise ValueError("saved category correction trigger differs")
            _replay_pass(artifact.passes[2], _requests(projection, artifact.config,
                selector, focus, artifact.profile,
                previous_wire=artifact.passes[1].raw_wire, feedback=failures),
                artifact.config, lambda raw: decode_document(raw, focus, projection),
                projection, focus, checker=_document_findings)
        elif failures and artifact.passes[1].outcome == "recoverable":
            raise ValueError("saved category correction is missing")
    elif len(artifact.passes) != 1:
        raise ValueError("saved category authoring follows failed selection")
    if artifact.focus_prepared != focus or artifact.selection_findings != selection_findings:
        raise ValueError("saved category preparation or selection audit differs")
    recoverable = tuple((index - 1, item.findings) for index, item in enumerate(artifact.passes)
                        if index >= 1 and item.outcome == "recoverable" and item.document is not None)
    chosen = (choose_recoverable(recoverable)[0] + 1 if recoverable else None)
    chosen_index = chosen if chosen is not None else 0
    resolved = (_answer(cast(StructuredDocument, artifact.passes[chosen_index].document),
                        cast(InteractivePreparedInput, focus), evidence,
                        artifact.passes[chosen_index].findings, selection_findings)
                if chosen is not None else None)
    terminal = artifact.passes[-1]
    validation = ("unavailable" if resolved is None else
                  "annotated" if any(f.outcome == "failed" for f in selection_findings) or any(f.outcome == "failed" for f in
                  artifact.passes[chosen_index].findings) else "clean")
    if (artifact.selected_pass_index != chosen or artifact.resolved != resolved or
            artifact.resolved_digest != (content_digest(resolved.model_dump(mode="json"))
                                         if resolved else None) or
            artifact.validation_outcome != validation or
            artifact.delivery_outcome != ("delivered" if resolved else "not_delivered") or
            artifact.generation_outcome != ("success" if resolved else terminal.outcome)):
        raise ValueError("saved category outcome differs")
    return resolved


def parse_category_artifact(raw: bytes | str) -> CategoryArtifact:
    value = json.loads(raw)
    if value.get("contract_version") != "results-category-artifact-v1":
        raise ValueError("unknown category artifact contract")
    return CategoryArtifact.model_validate(value)
