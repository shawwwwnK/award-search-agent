"""Exact model selection and selected-source packet for two-task Results authoring."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

from award_agent.ranking.projection_contracts import SolutionProjection

from .interactive_packet_v3 import reference_grammar_mode
from .interactive_packet_v4 import build_packet as build_joined_packet
from .structured_contracts import StructuredPreparedInput, StructuredSelection
from .workspace_contracts import WorkspaceEvidence

MAX_JOURNEYS = 8
MAX_LEADS = 8
MAX_TOTAL_REFERENCES = 8


def _roles(prepared: StructuredPreparedInput,
           source: SolutionProjection) -> tuple[list[str], list[str], list[str]]:
    refs = prepared.references
    eligible = {item.candidate_id for item in source.view.alternatives
                if item.status in {"admitted", "conditional"}}
    benchmarks = set(source.view.direct_cash_observation_ids)
    leads = (set(source.view.award_summary_observation_ids) |
             set(source.view.unmatched_award_observation_ids) |
             set(source.view.unpaired_positioning_observation_ids))
    journeys = [alias for alias, canonical in refs.journeys.items() if canonical in eligible]
    cash = [alias for alias, canonical in refs.cash.items() if canonical in benchmarks]
    incomplete = [alias for alias, canonical in (refs.awards | refs.cash).items()
                  if canonical in leads]
    if len(journeys) != len(eligible) or len(cash) != len(benchmarks) or len(incomplete) != len(leads):
        raise ValueError("selection references do not cover every source role")
    return journeys, cash, incomplete


def _enum_or_string(aliases: list[str], *, all_count: int) -> dict[str, object]:
    if aliases and all_count <= 1000 and (len(aliases) <= 250 or
                                          sum(map(len, aliases)) <= 15000):
        return {"type": "string", "enum": aliases}
    return {"type": "string"}


def selection_schema(prepared: StructuredPreparedInput,
                     source: SolutionProjection) -> dict[str, object]:
    journeys, cash, leads = _roles(prepared, source)
    total = len(journeys) + len(cash) + len(leads)
    j_item = _enum_or_string(journeys, all_count=total)
    l_item = _enum_or_string(leads, all_count=total)
    benchmark: dict[str, object] = ({"anyOf": [
        _enum_or_string(cash, all_count=total), {"type": "null"}]}
        if cash else {"type": "null"})
    return {"type": "object", "additionalProperties": False,
            "properties": {
                "journeys": {"type": "array", "items": j_item,
                             "minItems": 1 if journeys else 0,
                             "maxItems": MAX_JOURNEYS if journeys else 0},
                "benchmark": benchmark,
                "leads": {"type": "array", "items": l_item,
                          "minItems": 1 if not journeys and leads else 0,
                          "maxItems": MAX_LEADS if leads else 0},
            }, "required": ["journeys", "benchmark", "leads"]}


def selection_instructions(prepared: StructuredPreparedInput,
                           source: SolutionProjection) -> str:
    journeys, cash, leads = _roles(prepared, source)
    basis = (
        "Choose source references for one traveler answer from the COMPLETE indexed "
        "decision packet. This is selection only: return JSON aliases, no prose. "
        "You own the choices. Each journey is eligible but may be conditional; "
        "award summaries and partial components are leads, not complete journeys. "
        "Use exact J aliases for journeys, one exact direct cash C alias or null, "
        "and exact A/C lead aliases for partial observations. Every alias must "
        "match its source role. Prefer 2–4 meaningfully different journeys when "
        "the evidence supports them, plus relevant cash context and a few leads "
        "when useful. Do not choose a cash benchmark as an award journey. "
        "Selection must be defensible from route, timing, cabin scope, traveler "
        "support, fare scope, costs and relevant caveats; avoid unsupported "
        "cross-program economic ordering. Return no more than eight journeys "
        "and eight leads, and no more than eight references total including "
        "the benchmark; exceeding a bound is a failure, not truncation.")
    if not journeys:
        basis += (" No complete eligible journey exists; return journeys=[] and "
                  "select relevant incomplete leads when available. Do not imply "
                  "a date-only summary is a timed complete itinerary.")
    elif not leads:
        basis += " No incomplete leads are present; return leads=[]."
    if not cash:
        basis += " No direct cash benchmark is present; return benchmark=null."
    return basis


def decode_selection(raw: str | dict[str, Any], prepared: StructuredPreparedInput,
                     source: SolutionProjection) -> StructuredSelection:
    value = json.loads(raw) if isinstance(raw, str) else raw
    if not isinstance(value, dict) or set(value) != {"journeys", "benchmark", "leads"}:
        raise ValueError("selection must have exactly journeys, benchmark and leads")
    journeys, cash, leads = _roles(prepared, source)
    chosen_j, chosen_b, chosen_l = value["journeys"], value["benchmark"], value["leads"]
    if not isinstance(chosen_j, list) or not isinstance(chosen_l, list):
        raise TypeError("selection journeys and leads must be arrays")
    if not (1 if journeys else 0) <= len(chosen_j) <= (MAX_JOURNEYS if journeys else 0):
        raise ValueError("selection journey count is outside source-specific bounds")
    if not (1 if not journeys and leads else 0) <= len(chosen_l) <= (MAX_LEADS if leads else 0):
        raise ValueError("selection lead count is outside source-specific bounds")
    if len(chosen_j) + len(chosen_l) + (chosen_b is not None) > MAX_TOTAL_REFERENCES:
        raise ValueError("selection exceeds the eight-reference authoring bundle")
    if (any(not isinstance(item, str) for item in (*chosen_j, *chosen_l)) or
            len(set(chosen_j)) != len(chosen_j) or len(set(chosen_l)) != len(chosen_l)):
        raise ValueError("selection has non-string or duplicate aliases")
    if not set(chosen_j) <= set(journeys) or not set(chosen_l) <= set(leads):
        raise ValueError("selection has unknown or wrong-role references")
    if chosen_b is not None and (not isinstance(chosen_b, str) or chosen_b not in cash):
        raise ValueError("selection has an unknown or wrong-role cash benchmark")
    refs = prepared.references
    return StructuredSelection(
        journey_ids=tuple(refs.journeys[item] for item in chosen_j),
        benchmark_observation_id=refs.cash[chosen_b] if chosen_b else None,
        incomplete_observation_ids=tuple((refs.awards | refs.cash)[item]
                                             for item in chosen_l))


def _observed_path(facts: dict[str, Any]) -> list[str]:
    award = facts["award"]
    award_airports = award["airports"]
    if not isinstance(award_airports, list) or len(award_airports) < 2:
        raise ValueError("selected award has no exact ordered airport sequence")
    topology = facts["topology"]
    if topology == "award_only":
        result = award_airports
    elif topology in {"cash_access_award", "award_cash_egress"}:
        cash_facts = facts["cash"]
        cash_airports = cash_facts["airports"] if isinstance(cash_facts, dict) else None
        if not isinstance(cash_airports, list) or len(cash_airports) < 2:
            raise ValueError("selected cash component has no ordered airport sequence")
        if topology == "cash_access_award":
            if cash_airports[-1] != award_airports[0]:
                raise ValueError("selected cash access and award do not join exactly")
            result = [*cash_airports, *award_airports[1:]]
        else:
            if award_airports[-1] != cash_airports[0]:
                raise ValueError("selected award and cash egress do not join exactly")
            result = [*award_airports, *cash_airports[1:]]
    else:
        raise ValueError("selected journey has an unsupported packet topology")
    route = facts["route"]
    if result[0] != route["origin"] or result[-1] != route["destination"]:
        raise ValueError("selected observed path differs from journey route")
    return result


def _selected_cross_cabin(row: list[str], selected: set[str],
                          cabins: dict[str, str | None]) -> list[str] | None:
    members = [item for item in row if item in selected]
    known = {cabins.get(item) for item in members if cabins.get(item) not in
             {None, "unknown", "absent", "null", "-"}}
    return members if len(known) >= 2 else None


def build_packet(selection: StructuredSelection, prepared: StructuredPreparedInput,
                 source: SolutionProjection, evidence: WorkspaceEvidence) -> dict[str, Any]:
    """Expose only the model-selected exact source facts to the composer."""
    _roles(prepared, source)
    refs = prepared.references
    reverse = {canonical: alias for alias, canonical in
               (refs.journeys | refs.awards | refs.cash).items()}
    selected_j = [reverse[item] for item in selection.journey_ids]
    selected_b = None
    if selection.benchmark_observation_id is not None:
        if selection.benchmark_observation_id not in reverse:
            raise ValueError("selected benchmark has no exact source reference")
        selected_b = reverse[selection.benchmark_observation_id]
    selected_l = [reverse[item] for item in selection.incomplete_observation_ids]
    # Reapply exact role/count validation without silently fixing malformed input.
    decode_selection({"journeys": selected_j, "benchmark": selected_b,
                      "leads": selected_l}, prepared, source)
    full = build_joined_packet(prepared, source, evidence)
    by_short = {short: new for new, short in full["wire_aliases"].items()}
    selected_new_j = {by_short[item] for item in selected_j}
    selected_new_b = {by_short[selected_b]} if selected_b else set()
    selected_new_l = {by_short[item] for item in selected_l}
    packet = deepcopy(full)

    for section, allowed in (("journeys", selected_new_j),
                             ("benchmarks", selected_new_b), ("leads", selected_new_l)):
        filtered = []
        for group in full[section]:
            members = [member for member in group["members"] if member["ref"] in allowed]
            if members:
                facts = deepcopy(group["facts"])
                if section == "journeys":
                    facts["observed_airport_path"] = _observed_path(facts)
                filtered.append({"members": members, "facts": facts})
        packet[section] = filtered
        if {member["ref"] for group in filtered for member in group["members"]} != allowed:
            raise ValueError(f"selected {section} has no exact joined source facts")
    packet["ranking_hints"] = {key: [item for item in value if item in selected_new_j]
                               for key, value in full["ranking_hints"].items()}
    # Relations are evidence about the complete source pool. Stage two may make
    # comparisons only among shown choices, so keep only selected members.
    relations = full["relations"]
    selected_cabins = {member["ref"]: group["facts"].get("award_cabin")
                       for group in packet["journeys"] for member in group["members"]}
    packet["relations"] = {
        "same_award_arrival_alternatives": [
            {**row, "journey_refs": [item for item in row["journey_refs"]
                                     if item in selected_new_j]}
            for row in relations["same_award_arrival_alternatives"]
            if len([item for item in row["journey_refs"] if item in selected_new_j]) >= 2],
        "timing_match_cross_cabin": [cross_members for row in
            relations["timing_match_cross_cabin"]
            if (cross_members := _selected_cross_cabin(row, selected_new_j,
                                                        selected_cabins)) is not None],
        "lead_relevance": [
            {**row, "lead_refs": [item for item in row["lead_refs"]
                                if item in selected_new_l]}
            for row in relations["lead_relevance"]
            if any(item in selected_new_l for item in row["lead_refs"])],
    }
    # The decoder's local map is retained in the prepared artifact; the runtime
    # removes it from the writer payload, leaving only selected visible facts.
    used_refs = {member[key] for section in ("journeys", "benchmarks", "leads")
                 for group in packet[section] for member in group["members"]
                 for key in ("ref", "award_ref", "cash_ref")
                 if key in member and member[key] is not None}
    packet["wire_aliases"] = {new: old for new, old in full["wire_aliases"].items()
                              if new in used_refs}
    packet["format"] = "focused-v1"
    packet["outcome_mode"] = "complete_choices" if selected_j else "no_complete_journey"
    packet["wire_reference_grammar"] = reference_grammar_mode(packet)
    packet["legend"]["observed_airport_path"] = (
        "Ordered airport sequence joined only at equal cash-access/award boundary; "
        "it does not prove same aircraft, ticket protection or bookability.")
    packet["selection_scope"] = {
        "journey_count": len(selected_j), "lead_count": len(selected_l),
        "benchmark_selected": selected_b is not None,
        "meaning": "These are the model-selected facts only; comparisons and superlatives "
                   "must be limited to shown choices, not the unseen eligible pool."}
    return packet
