"""Check local call bounds, immutable request receipts, snapshots and exact replay."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path
from typing import Any

import ledger

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"


def _check_archive(run: Path, issues: list[str]) -> dict[str, bytes]:
    paths = ledger.read_json(run / "source-snapshot.json")
    archived: dict[str, bytes] = {}
    with zipfile.ZipFile(run / "source-snapshot.zip") as archive:
        if set(archive.namelist()) != set(paths):
            issues.append(f"{run.name}: snapshot archive members differ")
        for member, digest in paths.items():
            try:
                archived[member] = archive.read(member)
                observed = hashlib.sha256(archived[member]).hexdigest()
            except KeyError:
                observed = None
            if observed != digest:
                issues.append(f"{run.name}: snapshot digest differs: {member}")
    return archived


def _matches(run: Path, label: str, actual: object, expected: object,
             issues: list[str]) -> None:
    if actual != expected:
        issues.append(f"{run.name}: {label} differs from artifact")


def _artifact_integrity(run: Path, artifact: Any, summary: dict[str, Any],
                        settings: dict[str, Any], archived: dict[str, bytes],
                        reservations: dict[str, list[dict[str, Any]]],
                        issues: list[str]) -> None:
    from run import RECOVERY_DIAGNOSTIC_PROFILES, _preview, append_recovery_guidance

    from award_agent.results.contracts import ResultsConfig
    from award_agent.results.structured_contracts import StructuredResultsArtifact

    campaign_key = str(ledger.CAMPAIGN.relative_to(HERE.parents[4]))
    campaign = json.loads(archived[campaign_key])
    _matches(run, "campaign execution settings",
             (settings["model"], settings["max_output_tokens"],
              settings["timeout_seconds"], settings["max_retries"]),
             (campaign["model"], campaign["max_output_tokens"],
              campaign["timeout_seconds"], campaign["automatic_retries"]), issues)
    version = ("results-artifact-v11" if settings["profile"] in
               {"focused-v11", "focused-v12", "focused-v13"} else
               "results-artifact-v10" if settings["profile"] in
               {"focused-v8", "focused-v9", "focused-v10"} else
               "results-artifact-v8" if settings["profile"] == "focused-v3" else
               "results-artifact-v9")
    _matches(run, "artifact version for profile", artifact.contract_version,
             version, issues)
    profile_formats = {
        "focused-v3": ("roles-v2", "comparisons-v1"),
        "focused-v4": ("roles-v3", "complete-v1"),
        "focused-v5": ("roles-v4", "complete-v2"),
        "focused-v6": ("roles-v5", "complete-v3"),
        "focused-v7": ("roles-v6", "complete-v4"),
        "focused-v8": ("roles-v7", "complete-v5"),
        "focused-v9": ("roles-v8", "complete-v6"),
        "focused-v10": ("roles-v9", "complete-v7"),
        "focused-v11": ("roles-v10", "complete-v8"),
        "focused-v12": ("roles-v11", "complete-v9"),
        "focused-v13": ("roles-v12", "complete-v10"),
    }
    expected_formats = profile_formats[settings["profile"]]
    observed_formats = (artifact.selector_prepared.packet.get("selection_format"),
                        artifact.focus_prepared.packet.get("composition_format")
                        if artifact.focus_prepared is not None else None)
    if observed_formats[1] is not None:
        _matches(run, "profile selection/composition formats", observed_formats,
                 expected_formats, issues)
    else:
        _matches(run, "profile selection format", observed_formats[0],
                 expected_formats[0], issues)
    case = settings["case"]
    source_key = str((HERE.parent /
        "2026-10-25-cost-experiments/luna-retest/round-1" /
        case / "artifact.json").relative_to(HERE.parents[4]))
    config_key = str((HERE.parent /
        "2026-10-25-cost-experiments/luna-retest/round-1" /
        case / "config.json").relative_to(HERE.parents[4]))
    source = StructuredResultsArtifact.model_validate_json(archived[source_key])
    original_config = ResultsConfig.model_validate_json(archived[config_key])
    _matches(run, "original case config hash", settings.get("config_sha256"),
             hashlib.sha256(archived[config_key]).hexdigest(), issues)
    diagnostic = settings.get("recovery_diagnostic", False)
    guidance_key = str((HERE / "recovery-guidance.txt").relative_to(HERE.parents[4]))
    if diagnostic and (settings["profile"] not in RECOVERY_DIAGNOSTIC_PROFILES or
                       settings.get("manifest_sha256") is not None):
        issues.append(f"{run.name}: diagnostic was used for incompatible profile or confirmation")
    if diagnostic and settings.get("recovery_guidance_sha256") != hashlib.sha256(
            archived[guidance_key]).hexdigest():
        issues.append(f"{run.name}: diagnostic guidance hash differs")
    default_key = "data/results/fast-default.json"
    if settings.get("effective_config_source") is None:
        if settings.get("default_config_sha256") is not None:
            issues.append(f"{run.name}: default config hash lacks source marker")
        expected_config = original_config.model_copy(update={
            "model": "gpt-6-luna", "max_output_tokens": settings["max_output_tokens"],
            "timeout_seconds": float(settings["timeout_seconds"]),
            **({"authoring_guidance": archived[guidance_key].decode("utf-8")}
               if diagnostic else {})})
    else:
        _matches(run, "effective config source", settings["effective_config_source"],
                 default_key, issues)
        _matches(run, "proposed default config hash", settings.get("default_config_sha256"),
                 hashlib.sha256(archived[default_key]).hexdigest(), issues)
        candidate = ResultsConfig.model_validate_json(archived[default_key])
        _matches(run, "proposed default campaign model/output/timeout",
                 (candidate.model, candidate.max_output_tokens, candidate.timeout_seconds),
                 (campaign["model"], campaign["max_output_tokens"],
                  campaign["timeout_seconds"]), issues)
        expected_config = candidate.model_copy(update={"authoring_guidance":
            append_recovery_guidance(candidate.authoring_guidance,
                archived[guidance_key].decode("utf-8"))}) if diagnostic else candidate
    _matches(run, "source", artifact.evidence.source, source.evidence.source, issues)
    _matches(run, "effective config", artifact.config, expected_config, issues)
    if default_key in archived and not diagnostic and \
            settings.get("effective_config_source") is None:
        _matches(run, "snapshotted proposed default config",
                 artifact.config, ResultsConfig.model_validate_json(archived[default_key]), issues)
    _matches(run, "summary case", summary["case"], case, issues)
    _matches(run, "summary profile", summary["profile"], settings["profile"], issues)
    _matches(run, "summary diagnostic marker", summary.get("recovery_diagnostic", False),
             diagnostic, issues)
    _matches(run, "editorial revision marker", summary.get("editorial_revision", False),
             artifact.contract_version == "results-artifact-v10", issues)
    if artifact.contract_version == "results-artifact-v10":
        _matches(run, "revision trigger", summary.get("revision_trigger"),
                 artifact.revision_trigger, issues)
        _matches(run, "revision setting", artifact.revision_settings.reasoning_effort,
                 "low" if settings["profile"] == "focused-v9" else "medium", issues)
        if settings["profile"] == "focused-v10":
            _matches(run, "V10 draft effort", artifact.composer_settings.reasoning_effort,
                     "none", issues)
            _matches(run, "V10 selector effort", artifact.selector_settings.reasoning_effort,
                     "low", issues)
    if artifact.contract_version == "results-artifact-v11":
        _matches(run, "V11 selector effort", artifact.selector_settings.reasoning_effort,
                 "low", issues)
        _matches(run, "V11 composer effort", artifact.composer_settings.reasoning_effort,
                 "low" if settings["profile"] == "focused-v12" else "medium", issues)
        _matches(run, "V11 correction effort", artifact.correction_settings.reasoning_effort,
                 "low", issues)
        from award_agent.providers.contracts import content_digest

        _matches(run, "V11 registry digest", summary.get("comparison_registry_digest"),
                 content_digest(artifact.comparison_registry.model_dump(mode="json"))
                 if artifact.comparison_registry is not None else None, issues)
        _matches(run, "V11 visible comparison cards", summary.get("comparison_cards"),
                 [block.comparison.comparison_id for block in artifact.resolved.blocks
                  if block.kind == "comparison"] if artifact.resolved is not None else [], issues)
    if diagnostic:
        _matches(run, "diagnostic correction trigger", summary["recovery_triggered"],
                 len(artifact.passes) == 3, issues)
        _matches(run, "diagnostic fault observed", summary["diagnostic_fault_observed"],
                 len(artifact.passes) > 1 and any(
                     f.code == "visible_internal_alias" and f.outcome == "failed"
                     for f in artifact.passes[1].findings), issues)
        expected_failed = ([f.model_dump(mode="json") for f in artifact.passes[1].findings
                            if f.outcome == "failed"] if len(artifact.passes) > 1 else [])
        _matches(run, "diagnostic initial findings",
                 summary["initial_composition_failed_findings"], expected_failed, issues)
    _matches(run, "summary outcome", (
        summary["generation_outcome"], summary["validation_outcome"],
        summary["delivery_outcome"]), (
        artifact.generation_outcome, artifact.validation_outcome,
        artifact.delivery_outcome), issues)
    _matches(run, "summary pass phases/outcomes",
             [(row["phase"], row["outcome"]) for row in summary["passes"]],
             [(item.phase, item.outcome) for item in artifact.passes], issues)
    for index, item in enumerate(artifact.passes):
        raw = json.loads(item.writer_receipt.raw_response) if (
            item.writer_receipt and item.writer_receipt.raw_response) else {}
        _matches(run, f"pass {index + 1} summary tier and usage",
                 (summary["passes"][index]["returned_service_tier"],
                  summary["passes"][index]["usage"]),
                 (item.returned_service_tier, raw.get("usage")), issues)
    selected = getattr(artifact, "selected_pass_index", None)
    if selected is None and artifact.resolved is not None:
        selected = next((i for i in range(len(artifact.passes) - 1, -1, -1)
                         if artifact.passes[i].document is not None), None)
    _matches(run, "selected pass", summary["selected_pass_index"], selected, issues)
    selected_findings = artifact.passes[selected].findings if selected is not None else ()
    _matches(run, "selected failed findings", summary["failed_findings"],
             [finding.model_dump(mode="json") for finding in selected_findings
              if finding.outcome == "failed"], issues)
    if artifact.resolved is not None:
        _matches(run, "resolved.json", ledger.read_json(run / "resolved.json"),
                 artifact.resolved.model_dump(mode="json"), issues)
        _matches(run, "answer preview", (run / "answer-preview.md").read_text(),
                 _preview(artifact.resolved), issues)
    elif (run / "resolved.json").exists() or (run / "answer-preview.md").exists():
        issues.append(f"{run.name}: unavailable run has resolved answer files")
    for kind in ("count", "generation"):
        calls = [item for item in reservations[kind] if item["run_name"] == run.name]
        _matches(run, f"{kind} call count", len(calls), summary[f"{kind}_calls"], issues)
        if len(calls) > 3:
            issues.append(f"{run.name}: per-run {kind} bound exceeded")
    _matches(run, "generation calls and artifact",
             summary["generation_calls"], sum(item.writer_called for item in artifact.passes),
             issues)
    for index, item in enumerate(artifact.passes, 1):
        folder = run / f"pass-{index:02d}"
        if (folder / "count-request.json").exists():
            _matches(run, f"pass {index} count request",
                     ledger.read_json(folder / "count-request.json"), item.request, issues)
        if item.input_token_receipt is not None:
            _matches(run, f"pass {index} count receipt",
                     ledger.read_json(folder / "count-receipt.json"),
                     item.input_token_receipt.model_dump(mode="json"), issues)
        if item.writer_called:
            expected = dict(item.request, max_output_tokens=artifact.config.max_output_tokens,
                            store=False, truncation="disabled", stream=True)
            tier = (artifact.selector_settings.service_tier if index == 1 else
                    artifact.correction_settings.service_tier if index == 3 and
                    artifact.contract_version == "results-artifact-v11" else
                    artifact.revision_settings.service_tier if index == 3 and
                    artifact.contract_version == "results-artifact-v10" else
                    artifact.composer_settings.service_tier)
            if tier == "fast":
                expected["service_tier"] = "fast"
            _matches(run, f"pass {index} generation request",
                     ledger.read_json(folder / "generation-request.json"), expected, issues)
            if item.writer_receipt is not None:
                _matches(run, f"pass {index} writer receipt",
                         ledger.read_json(folder / "writer-receipt.json"),
                         item.writer_receipt.model_dump(mode="json"), issues)
                if item.writer_receipt.raw_response is not None:
                    _matches(run, f"pass {index} raw response",
                             ledger.read_json(folder / "raw-response.json"),
                             json.loads(item.writer_receipt.raw_response), issues)


def _manifest_integrity(run: Path, settings: dict[str, Any],
                        snapshot: dict[str, str], issues: list[str]) -> None:
    if settings.get("manifest_sha256") is None:
        return
    manifest_path = run / "manifest.json"
    if ledger.sha256(manifest_path) != settings["manifest_sha256"]:
        issues.append(f"{run.name}: frozen manifest hash differs")
    manifest = ledger.read_json(manifest_path)
    rows = [row for row in manifest["runs"] if row["name"] == run.name]
    if (len(rows) != 1 or rows[0]["case"] != settings["case"] or
            rows[0]["profile"] != settings["profile"] or
            rows[0]["source_sha256"] != settings["source_sha256"] or
            rows[0]["snapshot_hashes"] != snapshot or
            manifest["campaign_sha256"] != settings["campaign_sha256"]):
        issues.append(f"{run.name}: frozen manifest membership/source/code differs")


def report() -> dict[str, Any]:
    campaign = ledger.campaign()
    issues: list[str] = []
    reservations: dict[str, list[dict[str, Any]]] = {}
    for kind in ("count", "generation"):
        files = sorted(ledger.CALLS.glob(f"{kind}-*.json"))
        if len(files) > campaign["maximum_input_count_calls" if kind == "count"
                                 else "maximum_generation_calls"]:
            issues.append(f"{kind}: bound exceeded")
        ordinals = [int(file.stem.rsplit("-", 1)[-1]) for file in files]
        if ordinals != list(range(1, len(files) + 1)):
            issues.append(f"{kind}: reservation sequence has a gap")
        reservations[kind] = [ledger.read_json(path) for path in files]
    from award_agent.providers.contracts import content_digest
    from award_agent.results.focused import parse_focused_artifact, replay_focused_results
    summaries = []
    for run in sorted(RUNS.iterdir()) if RUNS.exists() else []:
        if not run.is_dir():
            continue
        try:
            settings = ledger.read_json(run / "settings.json")
            archived = _check_archive(run, issues)
            snapshot = ledger.read_json(run / "source-snapshot.json")
            if settings["source_sha256"] != snapshot[
                    str((HERE.parent / "2026-10-25-cost-experiments/luna-retest/round-1" /
                         settings["case"] / "artifact.json").relative_to(HERE.parents[4]))]:
                issues.append(f"{run.name}: saved source hash differs")
            if settings["campaign_sha256"] != snapshot[str(ledger.CAMPAIGN.relative_to(HERE.parents[4]))]:
                issues.append(f"{run.name}: campaign snapshot hash differs")
            _manifest_integrity(run, settings, snapshot, issues)
            artifact_path = run / "artifact.json"
            summary_path = run / "summary.json"
            if artifact_path.is_file() and summary_path.is_file():
                artifact = parse_focused_artifact(artifact_path.read_bytes())
                summary = ledger.read_json(summary_path)
                if replay_focused_results(artifact) != artifact.resolved:
                    issues.append(f"{run.name}: replay differs")
                _artifact_integrity(run, artifact, summary, settings, archived,
                                    reservations, issues)
                summaries.append({"run": run.name, "case": summary["case"],
                                  "profile": summary["profile"],
                                  "recovery_diagnostic": summary.get("recovery_diagnostic", False),
                                  "recovery_triggered": summary.get("recovery_triggered", False),
                                  "diagnostic_fault_observed": summary.get(
                                      "diagnostic_fault_observed", False),
                                  "seconds": summary["outer_results_completion_seconds"],
                                  "delivery": summary["delivery_outcome"],
                                  "validation": summary["validation_outcome"]})
            elif not (run / "run-error.json").is_file():
                issues.append(f"{run.name}: missing artifact/summary and error receipt")
            for kind in ("count", "generation"):
                for reservation in (item for item in reservations[kind]
                                    if item["run_name"] == run.name):
                    folder = run / reservation["label"]
                    request_path = folder / f"{kind}-request.json"
                    if not request_path.is_file():
                        issues.append(f"{run.name}: missing {kind} request")
                    elif content_digest(ledger.read_json(request_path)) != reservation["request_digest"]:
                        issues.append(f"{run.name}: {kind} request digest differs")
                    if not any((folder / file).is_file() for file in
                               (("count-receipt.json", "count-error.json") if kind == "count"
                                else ("writer-receipt.json", "generation-error.json"))):
                        issues.append(f"{run.name}: {kind} has no response/error receipt")
        except (OSError, KeyError, TypeError, ValueError, zipfile.BadZipFile) as exc:
            issues.append(f"{run.name}: verification error {type(exc).__name__}: {exc}")
    for kind in ("count", "generation"):
        for item in reservations[kind]:
            if not (RUNS / item["run_name"]).is_dir():
                issues.append(f"{kind}: reservation for missing run {item['run_name']}")
    return {"campaign": str(ledger.CAMPAIGN),
            "generation_reservations": len(reservations["generation"]),
            "count_reservations": len(reservations["count"]),
            "runs": summaries,
            "natural_runs": [row for row in summaries if not row["recovery_diagnostic"]],
            "recovery_diagnostic_runs": [row for row in summaries if row["recovery_diagnostic"]],
            "integrity_issues": issues}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    result = report()
    print(json.dumps(result, indent=2))
    return 1 if args.verify and result["integrity_issues"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
