"""V14 exact selector identities with an unverified editorial purpose note."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any, cast

from award_agent.ranking.projection_contracts import SolutionProjection

from .focused_packet import decode_selection_v2, selection_instructions_v8, selection_schema_v2
from .interactive_contracts import InteractivePreparedInput
from .structured_contracts import StructuredPreparedInput, StructuredSelection


def schema(prepared: StructuredPreparedInput, source: SolutionProjection) -> dict[str, object]:
    shape = deepcopy(selection_schema_v2(prepared, source))
    items = cast(dict[str, Any], shape["properties"])["choices"]["items"]
    branches = items.get("anyOf", [items])
    for branch in branches:
        properties = branch["properties"]
        properties["purpose"] = {"type": "string"}
        properties["compare_to"] = {"anyOf": [{"type": "string"}, {"type": "null"}]}
        branch["required"] = ["k", "r", "purpose", "compare_to"]
    return shape


def instructions(prepared: StructuredPreparedInput, source: SolutionProjection) -> str:
    basis = selection_instructions_v8(prepared, source).replace(
        "Return only JSON choices, no prose or copied source facts.",
        "Return only JSON choices with short editorial purpose text, no traveler answer prose or copied source facts.")
    return basis + (
        " For each selected choice, also return purpose: one short editorial "
        "hypothesis about why this exact choice helps the traveler decide, and "
        "compare_to: another selected exact alias or null. The output choice "
        "is {k:'j'|'b'|'l',r:exact alias,purpose:short text,compare_to:exact "
        "selected other alias or null}. Choose a comparison target when it "
        "helps reveal a concrete supported gain and real loss; otherwise null. "
        "Describe an intended traveler decision in purpose, not a new source "
        "value, repeated number or invented traveler preference. "
        "Do not choose near-identical siblings merely to fill the pool. If a "
        "same-program, same-cabin cousin looks worse on schedule and price, "
        "select it only for a source-supported offsetting traveler benefit. "
        "These purposes are unverified writing suggestions, not source facts "
        "or final recommendations. The composer must recheck every claim "
        "against each selected record and may reject a suggested purpose."
    )


def instructions_v15(prepared: StructuredPreparedInput, source: SolutionProjection) -> str:
    """Clarify partial-lead comparison only when no complete journey is eligible."""
    base = instructions(prepared, source)
    if any(item.status in {"admitted", "conditional"} for item in source.view.alternatives):
        return base
    return base + (
        " With no complete journey, look for a supported lead-to-lead difference "
        "that changes the next check: reported program, date, seat evidence or "
        "same-program quote with comparable currency and scope. In each useful "
        "purpose, name the lead's potential upside and its real tradeoff against "
        "another selected lead. A shared missing schedule is not a benefit. "
        "Keep direct cash as a separate baseline, not a substitute for a useful "
        "lead comparison. There is no lead count or cabin quota; one lead is "
        "enough when no other source-supported contrast helps the traveler. "
        "These purposes remain unverified hypotheses for the composer to check."
    )


def _choices(raw: str | dict[str, Any]) -> list[dict[str, Any]]:
    value = json.loads(raw) if isinstance(raw, str) else raw
    if not isinstance(value, dict) or set(value) != {"choices"} or not isinstance(value["choices"], list):
        raise ValueError("planned selection requires exactly a choices array")
    result = []
    for index, choice in enumerate(value["choices"]):
        if not isinstance(choice, dict) or set(choice) != {"k", "r", "purpose", "compare_to"}:
            raise ValueError(f"planned choice {index} has invalid fields")
        purpose, target = choice["purpose"], choice["compare_to"]
        if not isinstance(purpose, str) or not purpose.strip() or len(purpose) > 400:
            raise ValueError(f"planned choice {index} needs a short nonempty purpose")
        if target is not None and not isinstance(target, str):
            raise ValueError(f"planned choice {index} comparison target is invalid")
        result.append(choice)
    refs = [choice["r"] for choice in result]
    for index, choice in enumerate(result):
        target = choice["compare_to"]
        if target is not None and (target == choice["r"] or target not in refs):
            raise ValueError(f"planned choice {index} target must be another selected ref")
    return result


def decode(raw: str | dict[str, Any], prepared: StructuredPreparedInput,
           source: SolutionProjection) -> StructuredSelection:
    choices = _choices(raw)
    core = {"choices": [{"k": row["k"], "r": row["r"]} for row in choices]}
    return decode_selection_v2(core, prepared, source)


def editorial_plan(raw: str, selector: InteractivePreparedInput,
                   focus: InteractivePreparedInput,
                   selection: StructuredSelection,
                   source: SolutionProjection) -> list[dict[str, object]]:
    """Map selector notes to selected composer refs without promoting them to facts."""
    if decode(raw, selector.structured, source) != selection:
        raise ValueError("editorial plan identities differ from validated selection")
    reverse = {short: long for long, short in cast(dict[str, str],
               focus.packet["wire_aliases"]).items()}
    if len(reverse) != len(cast(dict[str, str], focus.packet["wire_aliases"])):
        raise ValueError("editorial plan has ambiguous exact source aliases")
    plan = []
    for choice in _choices(raw):
        ref = choice["r"]
        target = choice["compare_to"]
        if ref not in reverse or (target is not None and target not in reverse):
            raise ValueError("editorial plan aliases are outside selected authoring records")
        plan.append({"role": {"j": "journey", "b": "benchmark", "l": "lead"}[choice["k"]],
                     "ref": reverse[ref],
                     "purpose": choice["purpose"].strip(),
                     "compare_to": reverse[target] if target is not None else None,
                     "status": "unverified_editorial_suggestion"})
    return plan
