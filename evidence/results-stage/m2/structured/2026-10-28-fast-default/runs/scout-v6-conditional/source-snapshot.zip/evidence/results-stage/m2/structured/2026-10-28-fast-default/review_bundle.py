"""Prepare blind, source-grounded Results answer bundles for independent review."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import ledger

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"
INDEX = HERE / "review-index.json"


def create(run_name: str, bundle_name: str) -> Path:
    if (not run_name or Path(run_name).name != run_name or
            not bundle_name or Path(bundle_name).name != bundle_name):
        raise ValueError("names must be single path components")
    source = RUNS / run_name
    if not (source / "artifact.json").is_file():
        raise FileNotFoundError("run artifact is missing")
    if ledger.read_json(source / "settings.json").get("recovery_diagnostic", False):
        raise ValueError("recovery diagnostic cannot enter blind natural-answer review")
    index = ledger.read_json(INDEX) if INDEX.exists() else {}
    if bundle_name in index or f"runs/{run_name}" in index.values():
        raise ValueError("run or bundle already indexed")
    from award_agent.results.focused import parse_focused_artifact
    artifact = parse_focused_artifact((source / "artifact.json").read_bytes())
    selected_index = getattr(artifact, "selected_pass_index", None)
    if selected_index is None:
        selected_index = next((i for i in range(len(artifact.passes) - 1, -1, -1)
                               if artifact.passes[i].document is not None), None)
    if selected_index is None or artifact.resolved is None:
        raise ValueError("run has no resolved document to review")
    document = artifact.passes[selected_index].document
    if document is None:
        raise ValueError("selected pass has no document")
    preview = source / "answer-preview.md"
    if not preview.is_file():
        raise FileNotFoundError("answer preview is missing")
    target = HERE / "review-bundles" / bundle_name
    target.mkdir(parents=True, exist_ok=False)
    ledger.write_new(target / "document.json", document.model_dump(mode="json"))
    ledger.write_new(target / "evidence.json", artifact.evidence.model_dump(mode="json"))
    ledger.write_new(target / "references.json",
                     artifact.selector_prepared.structured.references.model_dump(mode="json"))
    (target / "answer.md").write_bytes(preview.read_bytes())
    # Reviewer-facing files contain no run arm, settings, timing, usage, or tier.
    index[bundle_name] = f"runs/{run_name}"
    temporary = INDEX.with_suffix(".tmp")
    temporary.write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    temporary.replace(INDEX)
    return target


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True)
    parser.add_argument("--bundle", required=True)
    args = parser.parse_args()
    print(create(args.run, args.bundle))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
