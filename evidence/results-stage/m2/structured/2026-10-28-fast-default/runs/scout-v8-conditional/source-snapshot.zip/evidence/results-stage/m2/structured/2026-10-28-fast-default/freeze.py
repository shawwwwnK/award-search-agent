"""Freeze a named prospective confirmation before any live run."""

from __future__ import annotations

import argparse
from datetime import UTC, datetime
from pathlib import Path

import ledger
import run


def freeze(path: Path, *, profile: str, repeat: int = 2,
           prefix: str | None = None) -> Path:
    if profile not in run.PROFILES or repeat < 1:
        raise ValueError("invalid profile or repetition count")
    prefix = prefix or path.stem
    if not prefix or not prefix.replace("-", "").replace("_", "").isalnum():
        raise ValueError("prefix must contain only letters, digits, - or _")
    needed = repeat * len(run.CASES) * ledger.campaign()["per_run_maximum_generations"]
    for kind in ("count", "generation"):
        if ledger.remaining(kind, ledger.campaign()) < needed:
            raise ValueError(f"campaign lacks {needed} {kind} slots for frozen cohort")
    rows = []
    for cohort in range(1, repeat + 1):
        for case in run.CASES:
            name = f"{prefix}-{cohort}-{case}"
            if (run.HERE / "runs" / name).exists():
                raise FileExistsError(f"confirmation run exists: {name}")
            rows.append({"name": name, "case": case, "profile": profile,
                         "source_sha256": ledger.sha256(run.SOURCE / case / "artifact.json"),
                         "snapshot_hashes": run.snapshot_hashes(case)})
    ledger.write_new(path, {"contract": "fast-default-confirmation-v1",
                            "frozen_at_utc": datetime.now(UTC).isoformat(),
                            "campaign_sha256": ledger.sha256(ledger.CAMPAIGN),
                            "runs": rows,
                            "gate": "Every run has useful, factually correct, complete M2 text and close to or below 20-second complete Results timing. Record every failure and all source-grounded review."})
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path)
    parser.add_argument("--profile", choices=run.PROFILES, default="focused-v6")
    parser.add_argument("--repeat", type=int, default=2)
    parser.add_argument("--prefix")
    args = parser.parse_args()
    print(freeze(args.path, profile=args.profile, repeat=args.repeat,
                 prefix=args.prefix))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
