"""Check local call bounds, immutable request receipts, snapshots and exact replay."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path
from typing import Any

import ledger

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"


def _check_archive(run: Path, issues: list[str]) -> dict[str, bytes]:
    paths = ledger.read_json(run / "source-snapshot.json")
    archived: dict[str, bytes] = {}
    with zipfile.ZipFile(run / "source-snapshot.zip") as archive:
        if set(archive.namelist()) != set(paths):
            issues.append(f"{run.name}: snapshot archive members differ")
        for member, digest in paths.items():
            try:
                archived[member] = archive.read(member)
                observed = hashlib.sha256(archived[member]).hexdigest()
            except KeyError:
                observed = None
            if observed != digest:
                issues.append(f"{run.name}: snapshot digest differs: {member}")
    return archived


def _matches(run: Path, label: str, actual: object, expected: object,
             issues: list[str]) -> None:
    if actual != expected:
        issues.append(f"{run.name}: {label} differs from artifact")


def _artifact_integrity(run: Path, artifact: Any, summary: dict[str, Any],
                        settings: dict[str, Any], archived: dict[str, bytes],
                        reservations: dict[str, list[dict[str, Any]]],
                        issues: list[str]) -> None:
    from run import _preview

    from award_agent.results.contracts import ResultsConfig
    from award_agent.results.structured_contracts import StructuredResultsArtifact

    campaign_key = str(ledger.CAMPAIGN.relative_to(HERE.parents[4]))
    campaign = json.loads(archived[campaign_key])
    _matches(run, "campaign execution settings",
             (settings["model"], settings["max_output_tokens"],
              settings["timeout_seconds"], settings["max_retries"]),
             (campaign["model"], campaign["max_output_tokens"],
              campaign["timeout_seconds"], campaign["automatic_retries"]), issues)
    _matches(run, "artifact version for profile", artifact.contract_version,
             "results-artifact-v9" if settings["profile"] in
             {"focused-v4", "focused-v5", "focused-v6"} else
             "results-artifact-v8", issues)
    profile_formats = {
        "focused-v3": ("roles-v2", "comparisons-v1"),
        "focused-v4": ("roles-v3", "complete-v1"),
        "focused-v5": ("roles-v4", "complete-v2"),
        "focused-v6": ("roles-v5", "complete-v3"),
    }
    expected_formats = profile_formats[settings["profile"]]
    observed_formats = (artifact.selector_prepared.packet.get("selection_format"),
                        artifact.focus_prepared.packet.get("composition_format")
                        if artifact.focus_prepared is not None else None)
    if observed_formats[1] is not None:
        _matches(run, "profile selection/composition formats", observed_formats,
                 expected_formats, issues)
    else:
        _matches(run, "profile selection format", observed_formats[0],
                 expected_formats[0], issues)
    case = settings["case"]
    source_key = str((HERE.parent /
        "2026-10-25-cost-experiments/luna-retest/round-1" /
        case / "artifact.json").relative_to(HERE.parents[4]))
    config_key = str((HERE.parent /
        "2026-10-25-cost-experiments/luna-retest/round-1" /
        case / "config.json").relative_to(HERE.parents[4]))
    source = StructuredResultsArtifact.model_validate_json(archived[source_key])
    original_config = ResultsConfig.model_validate_json(archived[config_key])
    expected_config = original_config.model_copy(update={
        "model": "gpt-6-luna", "max_output_tokens": settings["max_output_tokens"],
        "timeout_seconds": float(settings["timeout_seconds"])})
    _matches(run, "source", artifact.evidence.source, source.evidence.source, issues)
    _matches(run, "effective config", artifact.config, expected_config, issues)
    _matches(run, "summary case", summary["case"], case, issues)
    _matches(run, "summary profile", summary["profile"], settings["profile"], issues)
    _matches(run, "summary outcome", (
        summary["generation_outcome"], summary["validation_outcome"],
        summary["delivery_outcome"]), (
        artifact.generation_outcome, artifact.validation_outcome,
        artifact.delivery_outcome), issues)
    _matches(run, "summary pass phases/outcomes",
             [(row["phase"], row["outcome"]) for row in summary["passes"]],
             [(item.phase, item.outcome) for item in artifact.passes], issues)
    for index, item in enumerate(artifact.passes):
        raw = json.loads(item.writer_receipt.raw_response) if (
            item.writer_receipt and item.writer_receipt.raw_response) else {}
        _matches(run, f"pass {index + 1} summary tier and usage",
                 (summary["passes"][index]["returned_service_tier"],
                  summary["passes"][index]["usage"]),
                 (item.returned_service_tier, raw.get("usage")), issues)
    selected = getattr(artifact, "selected_pass_index", None)
    if selected is None and artifact.resolved is not None:
        selected = next((i for i in range(len(artifact.passes) - 1, -1, -1)
                         if artifact.passes[i].document is not None), None)
    _matches(run, "selected pass", summary["selected_pass_index"], selected, issues)
    selected_findings = artifact.passes[selected].findings if selected is not None else ()
    _matches(run, "selected failed findings", summary["failed_findings"],
             [finding.model_dump(mode="json") for finding in selected_findings
              if finding.outcome == "failed"], issues)
    if artifact.resolved is not None:
        _matches(run, "resolved.json", ledger.read_json(run / "resolved.json"),
                 artifact.resolved.model_dump(mode="json"), issues)
        _matches(run, "answer preview", (run / "answer-preview.md").read_text(),
                 _preview(artifact.resolved), issues)
    elif (run / "resolved.json").exists() or (run / "answer-preview.md").exists():
        issues.append(f"{run.name}: unavailable run has resolved answer files")
    for kind in ("count", "generation"):
        calls = [item for item in reservations[kind] if item["run_name"] == run.name]
        _matches(run, f"{kind} call count", len(calls), summary[f"{kind}_calls"], issues)
        if len(calls) > 3:
            issues.append(f"{run.name}: per-run {kind} bound exceeded")
    _matches(run, "generation calls and artifact",
             summary["generation_calls"], sum(item.writer_called for item in artifact.passes),
             issues)
    for index, item in enumerate(artifact.passes, 1):
        folder = run / f"pass-{index:02d}"
        if (folder / "count-request.json").exists():
            _matches(run, f"pass {index} count request",
                     ledger.read_json(folder / "count-request.json"), item.request, issues)
        if item.input_token_receipt is not None:
            _matches(run, f"pass {index} count receipt",
                     ledger.read_json(folder / "count-receipt.json"),
                     item.input_token_receipt.model_dump(mode="json"), issues)
        if item.writer_called:
            expected = dict(item.request, max_output_tokens=artifact.config.max_output_tokens,
                            store=False, truncation="disabled", stream=True)
            tier = (artifact.selector_settings.service_tier if index == 1 else
                    artifact.composer_settings.service_tier)
            if tier == "fast":
                expected["service_tier"] = "fast"
            _matches(run, f"pass {index} generation request",
                     ledger.read_json(folder / "generation-request.json"), expected, issues)
            if item.writer_receipt is not None:
                _matches(run, f"pass {index} writer receipt",
                         ledger.read_json(folder / "writer-receipt.json"),
                         item.writer_receipt.model_dump(mode="json"), issues)
                if item.writer_receipt.raw_response is not None:
                    _matches(run, f"pass {index} raw response",
                             ledger.read_json(folder / "raw-response.json"),
                             json.loads(item.writer_receipt.raw_response), issues)


def _manifest_integrity(run: Path, settings: dict[str, Any],
                        snapshot: dict[str, str], issues: list[str]) -> None:
    if settings.get("manifest_sha256") is None:
        return
    manifest_path = run / "manifest.json"
    if ledger.sha256(manifest_path) != settings["manifest_sha256"]:
        issues.append(f"{run.name}: frozen manifest hash differs")
    manifest = ledger.read_json(manifest_path)
    rows = [row for row in manifest["runs"] if row["name"] == run.name]
    if (len(rows) != 1 or rows[0]["case"] != settings["case"] or
            rows[0]["profile"] != settings["profile"] or
            rows[0]["source_sha256"] != settings["source_sha256"] or
            rows[0]["snapshot_hashes"] != snapshot or
            manifest["campaign_sha256"] != settings["campaign_sha256"]):
        issues.append(f"{run.name}: frozen manifest membership/source/code differs")


def report() -> dict[str, Any]:
    campaign = ledger.campaign()
    issues: list[str] = []
    reservations: dict[str, list[dict[str, Any]]] = {}
    for kind in ("count", "generation"):
        files = sorted(ledger.CALLS.glob(f"{kind}-*.json"))
        if len(files) > campaign["maximum_input_count_calls" if kind == "count"
                                 else "maximum_generation_calls"]:
            issues.append(f"{kind}: bound exceeded")
        ordinals = [int(file.stem.rsplit("-", 1)[-1]) for file in files]
        if ordinals != list(range(1, len(files) + 1)):
            issues.append(f"{kind}: reservation sequence has a gap")
        reservations[kind] = [ledger.read_json(path) for path in files]
    from award_agent.providers.contracts import content_digest
    from award_agent.results.focused import parse_focused_artifact, replay_focused_results
    summaries = []
    for run in sorted(RUNS.iterdir()) if RUNS.exists() else []:
        if not run.is_dir():
            continue
        try:
            settings = ledger.read_json(run / "settings.json")
            archived = _check_archive(run, issues)
            snapshot = ledger.read_json(run / "source-snapshot.json")
            if settings["source_sha256"] != snapshot[
                    str((HERE.parent / "2026-10-25-cost-experiments/luna-retest/round-1" /
                         settings["case"] / "artifact.json").relative_to(HERE.parents[4]))]:
                issues.append(f"{run.name}: saved source hash differs")
            if settings["campaign_sha256"] != snapshot[str(ledger.CAMPAIGN.relative_to(HERE.parents[4]))]:
                issues.append(f"{run.name}: campaign snapshot hash differs")
            _manifest_integrity(run, settings, snapshot, issues)
            artifact_path = run / "artifact.json"
            summary_path = run / "summary.json"
            if artifact_path.is_file() and summary_path.is_file():
                artifact = parse_focused_artifact(artifact_path.read_bytes())
                summary = ledger.read_json(summary_path)
                if replay_focused_results(artifact) != artifact.resolved:
                    issues.append(f"{run.name}: replay differs")
                _artifact_integrity(run, artifact, summary, settings, archived,
                                    reservations, issues)
                summaries.append({"run": run.name, "case": summary["case"],
                                  "profile": summary["profile"],
                                  "seconds": summary["outer_results_completion_seconds"],
                                  "delivery": summary["delivery_outcome"],
                                  "validation": summary["validation_outcome"]})
            elif not (run / "run-error.json").is_file():
                issues.append(f"{run.name}: missing artifact/summary and error receipt")
            for kind in ("count", "generation"):
                for reservation in (item for item in reservations[kind]
                                    if item["run_name"] == run.name):
                    folder = run / reservation["label"]
                    request_path = folder / f"{kind}-request.json"
                    if not request_path.is_file():
                        issues.append(f"{run.name}: missing {kind} request")
                    elif content_digest(ledger.read_json(request_path)) != reservation["request_digest"]:
                        issues.append(f"{run.name}: {kind} request digest differs")
                    if not any((folder / file).is_file() for file in
                               (("count-receipt.json", "count-error.json") if kind == "count"
                                else ("writer-receipt.json", "generation-error.json"))):
                        issues.append(f"{run.name}: {kind} has no response/error receipt")
        except (OSError, KeyError, TypeError, ValueError, zipfile.BadZipFile) as exc:
            issues.append(f"{run.name}: verification error {type(exc).__name__}: {exc}")
    for kind in ("count", "generation"):
        for item in reservations[kind]:
            if not (RUNS / item["run_name"]).is_dir():
                issues.append(f"{kind}: reservation for missing run {item['run_name']}")
    return {"campaign": str(ledger.CAMPAIGN),
            "generation_reservations": len(reservations["generation"]),
            "count_reservations": len(reservations["count"]),
            "runs": summaries, "integrity_issues": issues}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    result = report()
    print(json.dumps(result, indent=2))
    return 1 if args.verify and result["integrity_issues"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
